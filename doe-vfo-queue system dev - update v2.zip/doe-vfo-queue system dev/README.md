# DOE VFO Queue — Development

Lightweight Flask backend + static frontend for a VFO queue system.

**Project layout**
- [app.py](app.py) : Flask backend and API endpoints
- [index.html](index.html) : Main operator UI
- [display.html](display.html) : Public display for queue
- [js/](js/) : Frontend JavaScript (app.js, queue.js, data.js)
- [css/](css/) : Styles
- [sql/](sql/) : Database schema and migration scripts

**Features**
- REST API for queue management, staff, tracker, and establishments
- Static frontend served directly by Flask
- Simple round-robin staff assignment logic

**Requirements**
- Python 3.8+
- Packages: `flask`, `pymysql`, `python-dotenv` (optional), `flask-cors`

Install requirements:

```bash
pip install flask pymysql python-dotenv flask-cors
```

Or create a `requirements.txt` yourself with the above packages.

**Configuration**
The app reads database configuration from environment variables (or a `.env` file if `python-dotenv` is installed):

- `DB_HOST` — database host
- `DB_USER` — database username
- `DB_PASSWORD` — database password
- `DB_NAME` — database name (default: `dms_db`)

Example `.env` (create at project root):

```
DB_HOST=127.0.0.1
DB_USER=myuser
DB_PASSWORD=secret
DB_NAME=dms_db
```

**Database**
Use the SQL files in the [sql/](sql/) folder to create the schema or apply migrations. Start by inspecting:

- [sql/schema.sql](sql/schema.sql)
- [sql/migrate_fixes.sql](sql/migrate_fixes.sql)

The application expects tables such as `srf_servicerequest`, `auth_user`, and `accounts_userdata` to exist. Adjust the schema or the `DB_NAME` as needed.

**Run (development)**

```powershell
# On Windows PowerShell
python app.py
```

The server will start at `http://0.0.0.0:5001/` and serve the static files from the project root.

**Useful endpoints**
- `GET /api/queue` — fetch queue data
- `PUT /api/queue/<ticket>/serve` — mark a ticket as serving
- `GET /api/add_to_queue/<ticket>` — auto-assign staff and add to queue
- `GET /display` — public display page

**Development notes**
- `app.py` contains some commented-out helpers and endpoints left for future use.
- The app uses a simple ticket promotion logic and limits simultaneous `serving` clients to 4.

If you'd like, I can also add a `requirements.txt` and a small `.env.example` file.
# DOE Visayas Field Office – Queuing System

A plain HTML/CSS/JS queuing system. No build tools or dependencies required.

## Project structure

```
doe-queuing/
├── index.html          ← Main page (HTML structure + nav)
├── css/
│   └── style.css       ← All styles
└── js/
    ├── data.js         ← ✏️  EDIT THIS to change staff, services, cities, etc.
    ├── queue.js        ← Queue logic (add, call next, mark done, absent toggle)
    ├── signature.js    ← Canvas signature pad
    └── app.js          ← UI rendering and event handlers
```

## How to run

1. Open the folder in VS Code.
2. Install the **Live Server** extension (ritwickdey.liveserver) if you haven't.
3. Right-click `index.html` → **Open with Live Server**.
4. The app opens in your browser at `http://127.0.0.1:5500`.

You can also just double-click `index.html` to open it directly in any browser.

## Backend (Flask + MariaDB)

If you want to run the full server with a database (recommended for persistent data):

1. Copy `env.example` to `.env` and fill in your DB credentials (`DB_HOST`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`).
2. Create the database and apply the schema in the `sql/` folder (e.g. `sql/schema.sql`).
3. Install Python dependencies and run the Flask app:

```bash
python -m pip install flask pymysql python-dotenv flask-cors
python app.py
```

4. By default the server listens on `http://0.0.0.0:5000`. If you run the frontend separately, set `API_BASE='http://localhost:5000'` in [js/queue.js](js/queue.js).

See [app.py](app.py) for the available API endpoints.

## How to hardcode your own data

Open `js/data.js`. Everything you need to change is there with comments:

### Staff members

```js
const STAFF = [
  { id: 1, name: 'ML', initials: 'ML', window: 1, absent: false, served: 0 },
  // Add more lines here, just increment the id 
  // Name == initials 
  // Name and window part -> needed in the logic
];
```

### Services

```js
const SERVICES = [
  '------',
  '------',
  // Add or remove strings here
];
```

### Ticket prefix and starting number

```js
const TICKET_PREFIX = 'P';   // Change to 'B', 'C', etc.
const TICKET_START  = 0;     // Change to 100 to start at A-101
```

### Welcome name

In `index.html`, find and edit:

```html
<span class="welcome">Welcome! </span>
```

## Features

- **Service Request form** – fills in a ticket and assigns the next available staff member (round-robin).
- **Queue List** – shows all tickets with status. "Call Next" advances the queue. Manual Serve / Done buttons per row.
- **Now Serving** – hero display of the current ticket + live window cards for all staff.
- **Staff panel** – Mark Absent / Mark Present per staff member. Absent staff are skipped during assignment; any waiting tickets already assigned to them are auto-reassigned.
- **Customer Feedback** – simple satisfaction form.
