/**
 * data.js
 * -------
 * Hardcoded data for the DOE Visayas Field Office Queuing System.
 * Edit this file to update staff, services, and establishments.
 */

// ─── STAFF LIST ─────────────────────────────────────────────────────────────
// To add a staff member, copy one object and change the values.
// id       : unique number (don't repeat — must match the staff DB table)
// initials : shown everywhere in the UI (avatar, queue list, display board)
// absent   : set true to start them as absent on page load
// served   : leave as 0 (counts up during the session)


/*const SERVICES = [
  // EIMD
  'EIMD | Certificate of Compliance',
  'EIMD | Certificate of Registration',
  'EIMD | Issuance of Certificate of Non-Coverage',
  'EIMD | Issuance of Certification for Hauler (Own-use)',
  'EIMD | Issuance of LGU Permit Certification',
  'EIMD | License to Operate',
  // ERDUD
  'ERDUD | Issuance of Certificate of Coal End-User Registration (CEUR)',
  'ERDUD | Issuance of Certificate of Coal Trader Accreditation (CTA)',
  'ERDUD | Issuance of Small-Scale Coal Mining Permit (SSCMP) - Independent and Supervised by COC Holders - New and Renewal',
  'ERDUD | Safety Engineer and Safety Inspector',
  // Others
  'EPIMD | Others-Power Related',
  'EPIMD | Others-Coal Related',
  'EUMD | Others-Renewable / Efficiency Related',
  'OD | Others-Legal Concerns',
  'OIMD | Others-Oil Related',
]; */

// ─── ESTABLISHMENT CLASSIFICATIONS ───────────────────────────────────────────

/**const CLASSIFICATIONS = [
  'Liquid Fuels Retail Outlet',
  'Technology Solutions Retail Outlet',
  'Temporary Emergency Retail Outlet',
  'Marine Retail Outlet',
  'Others',
];
*/
// ─── ESTABLISHMENT NAMES ─────────────────────────────────────────────────────
// These appear in the "Establishment Name" dropdown.


// ─── CITIES / BARANGAYS ──────────────────────────────────────────────────────



// ─── STAFF SECTION PIN ───────────────────────────────────────────────────────
// Change this to any numeric PIN you want. Staff must enter this to access the
// Staff tab. Set to '' (empty string) to disable the PIN requirement.

const STAFF_PIN = '1234';
