/**
 * app.js
 * ------
 * UI controller + dropdowns.
 * Depends on: data.js, psgc_data.js, queue.js, signature.js
 */

// ─── BOOTSTRAP ───────────────────────────────────────────────────────────────

// Global establishments list loaded from DB
let establishments = [];

document.addEventListener('DOMContentLoaded', async function () {
  await loadState();           // fetch from server (localStorage not used)
  renderQueue();   
  renderServing();  
  renderStaff();

  // Restore last active tab + staff unlock (survives F5)
  const savedTab      = sessionStorage.getItem('doe-active-tab') || 'queue';
  const savedUnlocked = sessionStorage.getItem('doe-staff-unlocked') === '1';
  if (savedUnlocked) staffUnlocked = true;
  _restoreTab(savedTab);

  // Initialize CSM language defaults immediately
  //initCSM();

  // Keep all devices in sync via polling every 5 s
  startPolling(5000);
});

/**
 * Called by syncFromServer() after every poll.
 * Re-renders whichever tab is visible so the UI stays live on all devices.
 */
function onServerSync() {
  const activeTab = sessionStorage.getItem('doe-active-tab') || 'queue';
  if (activeTab === 'queue' && !isQueueDropdownActive()) renderQueue();
  if (activeTab === 'serving') renderServing();
  if (activeTab === 'staff')   renderStaff();
}

function isQueueDropdownActive() {
  return !!document.querySelector('#queue-tbody .cs-wrap.open');
}



// Close dropdowns when clicking outside
document.addEventListener('click', function (e) {
  document.querySelectorAll('.cs-wrap.open').forEach(wrap => {
    if (!wrap.contains(e.target)) csClose(wrap.id);
  });
});

// ─── CUSTOM SEARCHABLE SELECT ─────────────────────────────────────────────────
function renderProcessorDropdown(q) {
  const wrapId = `cs-proc-${q.id}`;
  const current = q.staff_initials || ' unassigned ';
  const items = [{ initials: '', label: ' unassigned ' },
                 ...staff.map(s => ({ initials: s.initials, label: s.initials }))];
  return `
    <div class="cs-wrap" id="${wrapId}" style="min-width:130px;font-size:12px">
      <div class="cs-selected" onclick="csToggle('${wrapId}')">${escHtml(current)}</div>
      <div class="cs-dropdown">
        <div class="cs-search-wrap">
          <input type="text" class="cs-search" placeholder="Search processor..."
            oninput="csFilter('${wrapId}')" onclick="event.stopPropagation()">
        </div>
        <div class="cs-list">
          ${items.map(it => `
            <div class="cs-item" onclick="csSelect('${wrapId}', ${q.id}, '${it.initials}')">
              ${escHtml(it.label)}
            </div>`).join('')}
        </div>
      </div>
    </div>`;
}

function csToggle(wrapId) {
  const wrap = document.getElementById(wrapId);
  if (!wrap) return;
  const wasOpen = wrap.classList.contains('open');
  document.querySelectorAll('.cs-wrap.open').forEach(w => csClose(w.id));
  if (!wasOpen) {
    wrap.classList.add('open');
    const input = wrap.querySelector('.cs-search');
    input.value = '';
    csFilterList(wrap, '');
    setTimeout(() => input.focus({ preventScroll: true }), 0);
  }
}

function csClose(wrapId) {
  const wrap = document.getElementById(wrapId);
  if (wrap) wrap.classList.remove('open');
}

function csFilter(wrapId) {
  const wrap = document.getElementById(wrapId);
  csFilterList(wrap, wrap.querySelector('.cs-search').value);
}

function csFilterList(wrap, query) {
  const q = query.trim().toLowerCase();
  let anyVisible = false;
  wrap.querySelectorAll('.cs-item').forEach(item => {
    const match = item.textContent.toLowerCase().includes(q);
    item.style.display = match ? '' : 'none';
    if (match) anyVisible = true;
  });
  let empty = wrap.querySelector('.cs-empty');
  if (!anyVisible && !empty) {
    empty = document.createElement('div');
    empty.className = 'cs-empty';
    empty.textContent = 'No matches';
    wrap.querySelector('.cs-list').appendChild(empty);
  } else if (anyVisible && empty) {
    empty.remove();
  }
}

async function csSelect(wrapId, ticketId, initials) {
  csClose(wrapId);
  await assignProcessor(ticketId, initials);
}

// ─── CASCADING ADDRESS DROPDOWNS ─────────────────────────────────────────────


// ─── TAB NAVIGATION ──────────────────────────────────────────────────────────

/** Switch tabs without triggering PIN prompt — used on page restore. */
function _restoreTab(tab) {
  const tabs = ['queue', 'serving', 'staff', 'tracker'];
  tabs.forEach(t => {
    const view = document.getElementById('view-' + t);
    const btn  = document.getElementById('tab-' + t);
    if (view) view.classList.toggle('hidden', t !== tab);
    if (btn)  btn.classList.toggle('active', t === tab);
  });
  if (tab === 'queue')    renderQueue();
  if (tab === 'serving')  renderServing();
  if (tab === 'staff')    renderStaff();
  if (tab === 'tracker')  initTracker();
} 

function showTab(tab) {
  if (tab === 'staff' && typeof STAFF_PIN !== 'undefined' && STAFF_PIN !== '') {
    if (!staffUnlocked) { openPinModal(); return; }
  }
  sessionStorage.setItem('doe-active-tab', tab);
  _restoreTab(tab);
}

// ─── PIN ─────────────────────────────────────────────────────────────────────

let staffUnlocked = false;

function openPinModal() {
  document.getElementById('pin-input').value = '';
  document.getElementById('pin-error').style.display = 'none';
  document.getElementById('pin-modal').classList.remove('hidden');
  setTimeout(() => document.getElementById('pin-input').focus(), 50);
}

function closePinModal() {
  document.getElementById('pin-modal').classList.add('hidden');
}

function checkPin() {
  const entered = document.getElementById('pin-input').value;
  if (entered === String(STAFF_PIN)) {
    staffUnlocked = true;
    sessionStorage.setItem('doe-staff-unlocked', '1');
    closePinModal();
    showTab('staff');
  } else {
    document.getElementById('pin-error').style.display = 'block';
    document.getElementById('pin-input').value = '';
    document.getElementById('pin-input').focus();
  }
}

// ─── FORM ────────────────────────────────────────────────────────────────────


// ─── TICKET MODAL ────────────────────────────────────────────────────────────

function showTicketModal(entry) {
  document.getElementById('modal-ticket').textContent  = entry.ticket;
  document.getElementById('modal-name').textContent    = entry.name || 'Client';
  document.getElementById('modal-service').textContent = entry.service;
  document.getElementById('modal-window').textContent  = entry.staff
    ? 'Assigned to: ' + entry.staff.initials
    : 'Please wait, all windows are currently busy';
  document.getElementById('ticket-modal').classList.remove('hidden');
}

function closeModal() {
  document.getElementById('ticket-modal').classList.add('hidden');
}

// ─── QUEUE VIEW ──────────────────────────────────────────────────────────────

function renderQueue() {
  updateStats();
  populateProcessorFilter();   // keep dropdown in sync

  const sortVal = (document.getElementById('q-sort') || {}).value || 'newest';
  const procVal = ((document.getElementById('q-processor') || {}).value || '').toUpperCase();

  let rows = [...queue];

  // Sort
  if (sortVal === 'newest') rows.reverse();

  // Filter by processor
  if (procVal) {
    rows = rows.filter(q => (q.staff_initials || '').toUpperCase() === procVal);
  }

  const tbody = document.getElementById('queue-tbody');
  if (!rows.length) {
    tbody.innerHTML = '<tr><td colspan="8" class="empty-row">No requests match the current filter.</td></tr>';
    return;
  }

  tbody.innerHTML = rows.map((q, i) => {
    const origIndex = queue.indexOf(q);   // keep actions pointing to real index
    return `
    <tr>
      <td><span class="ticket-num">${q.id}</span></td>
      <td>${escHtml(q.visitor || '—')}</td>
      <td style="font-size:11px;color:#666">${escHtml(q.bus_name || '—')}</td>
      <td style="font-size:11px">${escHtml(q.owner || '—')}</td>
      <td style="font-size:11px;color:#666">${escHtml(q.addr_txt || '—')}</td>
      <td>${escHtml(q.service_description || '—')}</td>
      <td>
        ${staffUnlocked ? renderProcessorDropdown(q) : escHtml(q.staff_initials || '—')}
      </td>
      <td><span class="badge badge-${q.status}">${statusLabel(q.status)}</span></td>
      <td>
        ${actionButton(q.status, origIndex, q.id)}
        <button class="btn-sm" style="margin-left:4px;background:#f0f0ff;color:#3d3db4;border-color:#c0c0ee"
          onclick="openNotesModal(${origIndex})" title="${q.notes ? escHtml(q.notes) : 'Add note'}">
          ${q.notes ? '📝' : '➕'} Note
        </button>
      </td>
    </tr>
    ${q.notes ? `<tr><td colspan="8" style="font-size:11px;color:#555;padding:2px 12px 8px;background:#fafafa;border-top:none">
      📝 <em>${escHtml(q.notes)}</em></td></tr>` : ''}`;
  }).join('');
}

function populateProcessorFilter() {
  const sel = document.getElementById('q-processor');
  if (!sel) return;
  const current = sel.value;

  // Collect unique processor initials from today's queue
  const seen = new Set();
  queue.forEach(q => { if (q.staff_initials) seen.add(q.staff_initials); });

  sel.innerHTML = '<option value="">All</option>';
  [...seen].sort().forEach(initials => {
    const opt = document.createElement('option');
    opt.value = initials.toLowerCase();
    opt.textContent = initials;
    if (initials.toLowerCase() === current) opt.selected = true;
    sel.appendChild(opt);
  });
}

function statusLabel(s) {
  if (s === 'waiting'){
    return 'Waiting';
  }
  else if (s === 'serving'){
    return 'Serving';
  }
  else if (s === 'done'){
    return 'Done';
  }
  else if (s === 'not_queued'){
    return 'Not Queued';  
  }
  else {
    return '-';
  }

 
}
function actionButton(status, index, id) {
  if (status === 'serving') return `<button class="btn-sm btn-success" onclick="doneAction(${id})">✓ Done</button>`;
  if (status === 'waiting') return `<button class="btn-sm" onclick="serveAction(${index})">▶ Serve</button>`;
  return '';
}
function updateStats() {
  const s = getStats();
  document.getElementById('stat-pending').textContent = s.waiting;
  document.getElementById('stat-serving').textContent = s.serving;
  document.getElementById('stat-done').textContent    = s.done;
}

//async function serveAction(index) { await serveByIndex(index); renderQueue(); renderServing(); }
async function serveAction(index) {
    const res = await fetch(`/api/queue/${queue[index].id}/serve`, { method: 'PUT' });
    if (!res.ok) {
        const err = await res.json();
        alert(err.error || 'Cannot serve at this time.');
        return;
    }
    await syncFromServer();
    renderQueue();
    renderServing();
}
// Before
/*async function doneAction(id) {
  const res = await fetch(`/api/queue/${id}/done`, { method: 'GET' });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    alert(err.error || 'Could not mark as done.');
    return;
  }
  await syncFromServer();
  renderQueue(); renderServing(); renderStaff();
}*/

// After
let _doneTargetId  = null;
let _doneDecision  = null;  // 1 = accepted, 0 = rejected

function doneAction(id) {
  _doneTargetId = id;
  _doneDecision = null;

  // Populate ticket number in modal
  const entry = queue.find(q => q.id === id);
  document.getElementById('done-modal-ticket').textContent = entry ? entry.id : id;

  // Reset modal state
  document.getElementById('done-remarks').value = entry ? (entry.remarks || '') : '';
  document.getElementById('done-decision-indicator').style.display = 'none';
  document.getElementById('done-btn-accept').style.outline = 'none';
  document.getElementById('done-btn-reject').style.outline = 'none';

  document.getElementById('done-modal').classList.remove('hidden');
}

function doneSetDecision(val) {
  _doneDecision = val;
  const indicator = document.getElementById('done-decision-indicator');

  if (val === 1) {
    indicator.textContent    = '✓ Marked as ACCEPTED';
    indicator.style.background = '#e6f4ea';
    indicator.style.color      = '#1e6e38';
    document.getElementById('done-btn-accept').style.outline = '3px solid #1e6e38';
    document.getElementById('done-btn-reject').style.outline = 'none';
  } else {
    indicator.textContent    = '✗ Marked as REJECTED';
    indicator.style.background = '#fdecea';
    indicator.style.color      = '#a32d2d';
    document.getElementById('done-btn-reject').style.outline = '3px solid #a32d2d';
    document.getElementById('done-btn-accept').style.outline = 'none';
  }
  indicator.style.display = 'block';
}

function closeDoneModal() {
  document.getElementById('done-modal').classList.add('hidden');
  _doneTargetId = null;
  _doneDecision = null;
}

async function submitDone() {
  if (_doneTargetId === null) return;
  if (_doneDecision === null) {
    alert('Please select Accept or Reject before confirming.');
    return;
  }

  const remarks = document.getElementById('done-remarks').value.trim();

  const res = await fetch(`/api/queue/${_doneTargetId}/done`, {
    method:  'PUT',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ accepted: _doneDecision, remarks }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    alert(err.error || 'Could not complete transaction.');
    return;
  }

  closeDoneModal();
  await syncFromServer();
  renderQueue(); renderServing(); renderStaff();
}


async function assignProcessor(ticketId, initials) {
  const res = await fetch(`/api/queue/${ticketId}/assign`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ initials }),
  });

  if (!res.ok) {
    alert('Failed to update processor.');
    await syncFromServer();
    renderQueue();
    return;
  }
// Update locally so it doesn't flicker on next sync
  const entry = queue.find(q => q.id === ticketId);
  if (entry) entry.staff_initials = initials;
  renderQueue();
}

// ─── NOW SERVING ─────────────────────────────────────────────────────────────

function renderServing() {
  const serving = queue.filter(q => q.status === 'serving');
  const noMsg   = document.getElementById('no-serving-msg');
  const display = document.getElementById('serving-display');
  if (!serving.length) { noMsg.classList.remove('hidden'); display.classList.add('hidden'); return; }
  noMsg.classList.add('hidden'); display.classList.remove('hidden');

  const latest = serving[serving.length - 1];
  document.getElementById('now-ticket').textContent  = latest.id;
  document.getElementById('now-name').textContent    = latest.visitor || 'Client';
  document.getElementById('now-service').textContent = latest.service_description || '';

  document.getElementById('window-grid').innerHTML = staff.map(s => {
    const cur = serving.find(q => (q.staff_initials || '').toUpperCase() === s.initials.toUpperCase());
    return `<div class="window-card ${cur ? 'serving-active' : ''}">
      <div class="w-agent">${escHtml(s.initials.toUpperCase())}</div>
      ${s.absent
        ? `<div class="w-client" style="margin-top:4px"><span class="absent-badge">Absent</span></div>`
        : cur
          ? `<div class="w-ticket">${cur.id}</div><div class="w-client">${escHtml(cur.visitor || 'Client')}</div>`
          : `<div class="w-client" style="margin-top:4px">Available</div>`}
    </div>`;
  }).join('');
}

// ─── STAFF ───────────────────────────────────────────────────────────────────

function renderStaff() {
  const avail = getAvailableStaff();
  document.getElementById('staff-avail-count').textContent =
    avail.length + ' of ' + staff.length + ' available';
  document.getElementById('staff-list').innerHTML = staff.map(s => {
    const cur = queue.find(q => q.status === 'serving' && q.staff && q.staff.id === s.id);
    return `<div class="staff-row ${s.absent ? 'absent' : ''}">
      <div class="staff-avatar">${escHtml(s.initials)}</div>
      <div class="staff-info">
        <div class="name">${escHtml(s.initials)} ${s.absent ? '<span class="absent-badge">Absent</span>' : ''}</div>
        <div class="role">${s.absent ? 'Absent' : 'On Duty'}</div>
      </div>
      <div class="staff-ticket-count">
        <div class="count-num">${s.served}</div>
        <div>served today</div>
        ${cur ? `<span class="window-tag">Serving ${cur.id}</span>` : ''}
      </div>
      <div class="staff-actions">
        <button class="btn-sm ${s.absent ? 'btn-success' : 'btn-danger'}" onclick="toggleAbsent(${s.id})">
          ${s.absent ? '✓ Mark Present' : '✗ Mark Absent'}
        </button>
      </div>
    </div>`;
  }).join('');
}

async function toggleAbsent(staffId) {
  await toggleStaffAbsent(staffId);
  renderStaff(); renderQueue(); renderServing();
}

// ─── EXCEL EXPORT ────────────────────────────────────────────────────────────

// CSM responses accumulate here each time csmSubmit() is called

function exportToExcel() {
  if (typeof XLSX === 'undefined') {
    alert('Excel library not loaded. Please check your internet connection.');
    return;
  }

  const wb = XLSX.utils.book_new();

  // ── Sheet 1: Queue Log ──────────────────────────────────────────────────────
  const queueHeader = [
    'Ticket', 'Visitor Name', 'Service', 'Establishment',
    'Email', 'Mobile', 'Address', 'Staff',
    'Status', 'Time', 'Notes'
  ];
  const queueRows = queue.map(q => [
    q.id      || '',
    q.name    || '',
    q.service || '',
    q.estab   || '',
    q.email   || '',
    q.mobile  || '',
    q.address || '',
    q.staff   ? q.staff.initials : '',
    q.status  === 'waiting' ? 'Waiting' : q.status === 'serving' ? 'Serving' : 'Done',
    q.time    || '',
    q.notes   || '',
  ]);
  const queueSheet = XLSX.utils.aoa_to_sheet([queueHeader, ...queueRows]);

  // Column widths
  queueSheet['!cols'] = [
    {wch:10},{wch:24},{wch:48},{wch:36},{wch:30},{wch:16},
    {wch:36},{wch:8},{wch:10},{wch:8},{wch:40}
  ];
  XLSX.utils.book_append_sheet(wb, queueSheet, 'Queue Log');

  // ── Sheet 2: Staff Summary ──────────────────────────────────────────────────
  const staffHeader = ['Initials', 'Status', 'Served Today'];
  const staffRows = staff.map(s => [
    s.initials,
    s.absent ? 'Absent' : 'Present',
    s.served,
  ]);
  const statsRow = getStats();
  const staffSheet = XLSX.utils.aoa_to_sheet([
    staffHeader,
    ...staffRows,
    [],
    ['Summary', '', ''],
    ['Total Waiting',  '', statsRow.waiting],
    ['Total Serving',  '', statsRow.serving],
    ['Total Done',     '', statsRow.done],
  ]);
  staffSheet['!cols'] = [{wch:12},{wch:10},{wch:14}];
  XLSX.utils.book_append_sheet(wb, staffSheet, 'Staff Summary');

  // ── Sheet 3: CSM Feedback ───────────────────────────────────────────────────

  // ── Download ────────────────────────────────────────────────────────────────
  const today = new Date().toISOString().slice(0,10);
  XLSX.writeFile(wb, 'DOE-VFO-Queue-' + today + '.xlsx');
}

// ─── FEEDBACK / CSM ──────────────────────────────────────────────────────────

async function resetDay() {
  if (!confirm('Reset the entire queue for today? This cannot be undone.')) return;
  await clearState();
  location.reload();
}


// ─── NOTES MODAL ─────────────────────────────────────────────────────────────

let notesTargetIndex = -1;

function openNotesModal(index) {
  notesTargetIndex = index;
  const entry = queue[index];
  if (!entry) return;
  document.getElementById('notes-modal-ticket').textContent = entry.ticket;
  document.getElementById('notes-textarea').value = entry.notes || '';
  document.getElementById('notes-modal').classList.remove('hidden');
  setTimeout(() => document.getElementById('notes-textarea').focus(), 50);
}

function closeNotesModal() {
  document.getElementById('notes-modal').classList.add('hidden');
  notesTargetIndex = -1;
}

async function saveNotes() {
  if (notesTargetIndex < 0) return;
  const entry = queue[notesTargetIndex];
  if (!entry) return;
  const notes = document.getElementById('notes-textarea').value.trim();
  try {
    await fetch(`/api/queue/${entry.id}/notes`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ notes })
    });
    entry.notes = notes;
  } catch(e) { console.warn('Could not save notes', e); }
  closeNotesModal();
  renderQueue();
}

// ─── ADD NEW ESTABLISHMENT MODAL ─────────────────────────────────────────────

// ─── TRACKER ─────────────────────────────────────────────────────────────────

let trCurrentTab = 'estab';
let trEstabData  = [];
let trServiceData = [];

function initTracker() {
  // Set default dates to today if not set
  const today = new Date().toISOString().slice(0, 10);
  const fromEl = document.getElementById('tr-from');
  const toEl   = document.getElementById('tr-to');
  if (!fromEl.value) fromEl.value = today;
  if (!toEl.value)   toEl.value   = today;
  loadTracker();
}

async function loadTracker() {
  const from = document.getElementById('tr-from').value;
  const to   = document.getElementById('tr-to').value;
  if (!from || !to) return;

  try {
    const [summaryRes, estabRes, serviceRes] = await Promise.all([
      fetch(`/api/tracker/summary?from=${from}&to=${to}`),
      fetch(`/api/tracker/establishments?from=${from}&to=${to}`),
      fetch(`/api/tracker/services?from=${from}&to=${to}`),
    ]);

    const summary  = await summaryRes.json();
    trEstabData    = await estabRes.json();
    trServiceData  = await serviceRes.json();

    renderTrackerSummary(summary);
    renderEstabTracker();
    renderServiceTracker();
  } catch(e) {
    console.error('Tracker load failed', e);
  }
}

function renderTrackerSummary(s) {
  document.getElementById('tr-total').textContent      = s.total_transactions || 0;
  document.getElementById('tr-estabs').textContent     = s.unique_establishments || 0;
  document.getElementById('tr-done').textContent       = s.completed || 0;
  document.getElementById('tr-processors').textContent = s.processors_active || 0;
}

function trShowTab(tab) {
  trCurrentTab = tab;
  const tabs = ['estab', 'service'];
  tabs.forEach(t => {
    const btn  = document.getElementById('tr-tab-' + t);
    const view = document.getElementById('tr-view-' + t);
    const active = t === tab;
    if (btn) {
      btn.style.borderBottomColor = active ? '#3d3db4' : 'transparent';
      btn.style.color = active ? '#3d3db4' : '#888';
      btn.style.fontWeight = active ? '600' : '400';
    }
    if (view) view.style.display = active ? '' : 'none';
  });
}

function renderEstabTracker() {
  const container = document.getElementById('tr-estab-list');
  if (!trEstabData.length) {
    container.innerHTML = '<div class="empty-row" style="text-align:center;padding:24px;color:#aaa">No transactions found for this date range.</div>';
    return;
  }

  container.innerHTML = trEstabData.map(estab => `
    <div style="border:1px solid #e0e0e0;border-radius:10px;margin-bottom:14px;overflow:hidden">
      <!-- Establishment header -->
      <div style="background:#f0f0fa;padding:10px 16px;display:flex;align-items:center;gap:12px;flex-wrap:wrap">
        <span style="background:#3d3db4;color:#fff;border-radius:6px;padding:2px 8px;font-size:11px;font-weight:700">#${estab.estab_id || '?'}</span>
        <span style="font-weight:700;font-size:14px;color:#222">${escHtml(estab.estab_name)}</span>
        ${estab.dealer ? `<span style="font-size:11px;color:#666">— ${escHtml(estab.dealer)}</span>` : ''}
        <span style="margin-left:auto;background:#eee;border-radius:10px;padding:2px 10px;font-size:11px;color:#444">${estab.visits.length} transaction${estab.visits.length !== 1 ? 's' : ''}</span>
      </div>
      <!-- Transactions table -->
      <div style="overflow-x:auto">
        <table style="width:100%;border-collapse:collapse;font-size:12px">
          <thead>
            <tr style="background:#fafafa;border-bottom:1px solid #e0e0e0">
              <th style="padding:7px 12px;text-align:left;color:#666;font-weight:600">Ticket</th>
              <th style="padding:7px 12px;text-align:left;color:#666;font-weight:600">Client</th>
              <th style="padding:7px 12px;text-align:left;color:#666;font-weight:600">Service Availed</th>
              <th style="padding:7px 12px;text-align:left;color:#666;font-weight:600">Processor</th>
              <th style="padding:7px 12px;text-align:left;color:#666;font-weight:600">Status</th>
              <th style="padding:7px 12px;text-align:left;color:#666;font-weight:600">Date / Time</th>
              <th style="padding:7px 12px;text-align:left;color:#666;font-weight:600">Notes</th>
            </tr>
          </thead>
          <tbody>
            ${estab.visits.map(v => `
              <tr style="border-bottom:1px solid #f5f5f5">
                <td style="padding:7px 12px"><span class="ticket-num" style="font-size:12px">${escHtml(v.ticket)}</span></td>
                <td style="padding:7px 12px">${escHtml(v.client_name || '—')}</td>
                <td style="padding:7px 12px;color:#555;max-width:220px">${escHtml(v.service || '—')}</td>
                <td style="padding:7px 12px"><span style="background:#eef0fb;color:#3d3db4;border-radius:4px;padding:2px 7px;font-weight:600">${escHtml(v.processor)}</span></td>
                <td style="padding:7px 12px"><span class="badge badge-${v.status}">${statusLabel(v.status)}</span></td>
                <td style="padding:7px 12px;color:#888">${escHtml(v.date)} ${escHtml(v.time || '')}</td>
                <td style="padding:7px 12px;color:#666;font-style:italic;max-width:180px">${v.notes ? escHtml(v.notes) : '<span style="color:#ccc">—</span>'}</td>
              </tr>`).join('')}
          </tbody>
        </table>
      </div>
    </div>`).join('');
}

function renderServiceTracker() {
  const tbody = document.getElementById('tr-service-tbody');
  if (!trServiceData.length) {
    tbody.innerHTML = '<tr><td colspan="6" class="empty-row">No services found.</td></tr>';
    return;
  }
  tbody.innerHTML = trServiceData.map(s => `
    <tr>
      <td style="font-size:12px;color:#333">${escHtml(s.service || '—')}</td>
      <td style="text-align:center;font-weight:700;color:#3d3db4">${s.total}</td>
      <td style="text-align:center"><span class="badge badge-done">${s.done || 0}</span></td>
      <td style="text-align:center"><span class="badge badge-serving">${s.serving || 0}</span></td>
      <td style="text-align:center"><span class="badge badge-waiting">${s.waiting || 0}</span></td>
      <td style="font-size:11px;color:#888;max-width:200px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"
          title="${escHtml(s.establishments || '')}">${escHtml(s.establishments || '—')}</td>
    </tr>`).join('');
}

/**function exportTrackerExcel() {
  if (!window.XLSX) { alert('Excel library not loaded.'); return; }
  const from = document.getElementById('tr-from').value;
  const to   = document.getElementById('tr-to').value;

  // Sheet 1: All transactions flat
  const flat = [];
  trEstabData.forEach(estab => {
    estab.visits.forEach(v => {
      flat.push({
        'Ticket':             v.ticket,
        'Establishment':      estab.estab_name,
        'Establishment ID':   estab.estab_id || '',
        'Dealer/Owner':       estab.dealer || '',
        'Client Name':        v.client_name || '',
        'Service Availed':    v.service || '',
        'Processor':          v.processor || '',
        'Status':             v.status,
        'Date':               v.date,
        'Time':               v.time || '',
        'Notes/Remarks':      v.notes || '',
      });
    });
  });

  // Sheet 2: Service summary
  const svcFlat = trServiceData.map(s => ({
    'Service Availed': s.service,
    'Total':           s.total,
    'Done':            s.done || 0,
    'Serving':         s.serving || 0,
    'Waiting':         s.waiting || 0,
    'Establishments':  s.establishments || '',
  }));

  const wb   = XLSX.utils.book_new();
  const ws1  = XLSX.utils.json_to_sheet(flat);
  const ws2  = XLSX.utils.json_to_sheet(svcFlat);

  XLSX.utils.book_append_sheet(wb, ws1, 'Transactions');
  XLSX.utils.book_append_sheet(wb, ws2, 'Services Summary');
  XLSX.writeFile(wb, `doe_tracker_${from}_to_${to}.xlsx`);
}
*/

// ─── UTILS ───────────────────────────────────────────────────────────────────

function escHtml(str) {
  return String(str)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}