"""
app.py  –  Flask + MariaDB (PyMySQL) backend
"""

import os
import pymysql
import pymysql.cursors
from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
from datetime import date, datetime
import traceback

# Load .env file if present (pip install python-dotenv)
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

app = Flask(__name__, static_folder='.')
CORS(app)

# ── DB CONFIG ──────────────────────────────────────────────────────────────────
DB_CONFIG = {
    'host':            os.environ.get('DB_HOST',     ''),
    'user':            os.environ.get('DB_USER',     ''),
    'password':        os.environ.get('DB_PASSWORD', ''),
    'database':        os.environ.get('DB_NAME',     'dms_db'),
    'cursorclass':     pymysql.cursors.DictCursor,
    'charset':         'utf8mb4',
    'auth_plugin_map': {'auth_gssapi_client': None},
}

def get_db():
    return pymysql.connect(**DB_CONFIG)

'''def pick_next_staff(cur):
    """
    Round-robin via 'last assigned' reference point.
    - Pulls all non-absent staff (division='eimd'), ordered by id.
    - Finds who was served_by_id most recently (globally, by MAX(date_log)).
    - Starts checking from the staff right after that person in the list,
      wrapping around, skipping anyone currently busy (serving today).
    Returns assigned_staff_row or None.
    """
    cur.execute("""
        SELECT au.id, au.username AS initials
        FROM auth_user au
        JOIN accounts_userdata ud ON ud.user_id = au.id
        WHERE ud.division = 'eimd' AND ud.is_absent = 0
        ORDER BY au.id
    """)
    available = cur.fetchall()
    if not available:
        return None

    cur.execute(
        "SELECT served_by_id FROM srf_servicerequest "
        "WHERE status = 'serving' "
        "AND served_by_id IS NOT NULL"
    )
    busy_ids = {r['served_by_id'] for r in cur.fetchall()}

    # Find the single most recently assigned staff member, overall
    cur.execute("""
        SELECT served_by_id
        FROM srf_servicerequest
        WHERE served_by_id IS NOT NULL
        AND entertained_on IS NOT NULL 
        ORDER BY date_log DESC
        LIMIT 1
    """)
    last_row = cur.fetchone()
    last_assigned_id = last_row['served_by_id'] if last_row else None

    n = len(available)
    start = 0
    if last_assigned_id is not None:
        idx = next((i for i, s in enumerate(available) if s['id'] == last_assigned_id), None)
        if idx is not None:
            start = (idx + 1) % n   # start checking from the next one in line

    for step in range(n):
        candidate = available[(start + step) % n]
        if candidate['id'] not in busy_ids:
            return candidate

    return None  # everyone available is currently busy
'''

# ── FRONTEND ───────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

@app.route('/display')
def display():
    return send_from_directory('.', 'display.html')

@app.route('/<path:filename>')
def static_files(filename):
    return send_from_directory('.', filename)

# ── ESTABLISHMENTS ─────────────────────────────────────────────────────────────

@app.route('/api/establishments', methods=['GET'])
def get_establishments():
    conn = get_db()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT id, bus_name AS business,
                       CONCAT_WS(' ', NULLIF(TRIM(fname),''), NULLIF(TRIM(lname),'')) AS dealer
                FROM srf_servicerequest
                ORDER BY bus_name
            """)
            return jsonify(cur.fetchall())
    finally:
        conn.close()
'''
@app.route('/api/establishments', methods=['POST'])
def add_establishment():
    data     = request.json or {}
    business = (data.get('business') or '').strip()
    dealer   = (data.get('dealer')   or '').strip()
    if not business:
        return jsonify({'error': 'Business name is required'}), 400
    conn = get_db()
    try:
        with conn.cursor() as cur:
            # Check which columns exist so we only insert what's there
            cur.execute("SHOW COLUMNS FROM srf_servicerequest")
            cols = {r['Field'] for r in cur.fetchall()}

            fields = ['bus_name']
            values = [business]

            if 'fname' in cols:
                fields.append('fname')
                values.append(dealer)
            if 'lname' in cols:
                fields.append('lname')
                values.append('')

            nullable_defaults = {
                'accepted':           0,
                'entertained_by_id':  None,
                'served_by_id':       None,
                'service_availed_id': None,
                'doc_sn_id':          None,
            }
            for col, val in nullable_defaults.items():
                if col in cols:
                    fields.append(col)
                    values.append(val)

            # Lock to prevent duplicate ID race condition
            cur.execute("SELECT COALESCE(MAX(id), 0) + 1 AS next_id FROM srf_servicerequest FOR UPDATE")
            next_id = cur.fetchone()['next_id']

            fields.insert(0, 'id')
            values.insert(0, next_id)
            placeholders = ', '.join(['%s'] * len(fields))
            col_str      = ', '.join(fields)

            cur.execute(
                f"INSERT INTO srf_servicerequest ({col_str}) VALUES ({placeholders})",
                values
            )
            new_id = next_id
        conn.commit()
        return jsonify({'id': new_id, 'business': business, 'dealer': dealer})
    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()
'''
# ── STAFF ──────────────────────────────────────────────────────────────────────

@app.route('/api/staff', methods=['GET'])
def get_staff():
    conn = get_db()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT 
                    au.id, 
                    au.username,
                    ud.is_absent,
                    COUNT(sr.id) AS served
                FROM auth_user au
                JOIN accounts_userdata ud ON ud.user_id = au.id
                LEFT JOIN srf_servicerequest sr 
                    ON sr.served_by_id = au.id
                    AND sr.status = 'done'
                    AND DATE(sr.entertained_on) = CURDATE()
                WHERE ud.division = 'eimd'
                GROUP BY au.id, au.username, ud.is_absent
                ORDER BY au.id
            """)
            rows = cur.fetchall()
        for r in rows:
            r['is_absent'] = bool(r['is_absent'])
        return jsonify(rows)
    finally:
        conn.close()

@app.route('/api/staff/<int:staff_id>/toggle', methods=['PUT'])
def toggle_staff(staff_id):
    conn = get_db()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT is_absent FROM accounts_userdata WHERE user_id = %s AND division = 'eimd'",
                (staff_id,)
            )
            row = cur.fetchone()
            if not row:
                return jsonify({'error': 'Not found'}), 404
            new_val = 0 if row['is_absent'] else 1
            cur.execute(
                "UPDATE accounts_userdata SET is_absent = %s WHERE user_id = %s AND division = 'eimd'",
                (new_val, staff_id)
            )
        conn.commit()
        return jsonify({'is_absent': bool(new_val)})
    finally:
        conn.close()

# ── QUEUE ──────────────────────────────────────────────────────────────────────
#FETCH ALL QUEUE DATA FROM DATABASE NOT YET SERVED OR SERVING
@app.route('/api/queue', methods=['GET'])
def get_queue():
    #today = date.today()
    #today = date(2026, 6, 22)
    conn  = get_db()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT 
                    q.id,
                    q.bus_name,
                    sa.description AS service_description,
                    sa.title AS service_title,
                    q.email,
                    q.mobile,
                    q.addr_txt,
                    q.status,
                    q.date_log,
                    q.remarks,
                    ua.username as staff_initials,

                    CONCAT_WS(' ', NULLIF(TRIM(q.visitor_fname),''), NULLIF(TRIM(q.visitor_lname),'')) AS visitor,
                    q.bus_name AS estab,
                    CONCAT_WS(' ', NULLIF(TRIM(q.fname),''), NULLIF(TRIM(q.lname),'')) AS owner
                FROM   srf_servicerequest q
                LEFT JOIN process_flow_service sa
                    ON sa.id = q.service_availed_id
                LEFT JOIN auth_user ua
                    ON ua.id = q.served_by_id
                WHERE q.status IN ('waiting', 'serving')
                OR (q.status = 'done' AND DATE(q.date_served) = CURDATE())
                ORDER BY q.id
            """)
            rows = cur.fetchall()

        queue = []

        '''for r in rows:
            entry = {
                'ticket':              r['ticket'],
                'name':                r['name'],
                'service':             r['service'],
                'estab_id':            r['estab_id'],
                # Live name from srf_servicerequest; fall back to snapshot if JOIN is null
                'estab':               r['estab'] or '',
                'owner':               r['owner'] or '',
                'email':               r['email'],
                'mobile':              r['mobile'],
                'address':             r['address'],
                'status':              r['status'],
                'notes':               r['notes'],
                'signature':           r['signature'],
                'date':                str(r['date_log']) if r['date_log'] else None,
                # Prefer proper TIME column; fall back to legacy time_str
                'time':                str(r['time_log']) if r['time_log'] else r['time_str'],
                #'staff':               {'id': r['staff_id'], 'initials': r['staff_initials']} if r['staff_id'] else None,
            }
            queue.append(entry)
        '''
        return jsonify({'queue': rows, 'ticketCounter': 0,
                        'nextAssignIndex': 0})
    finally:
        conn.close()

@app.route('/api/add_to_queue/<int:ticket>', methods=['GET'])
def add_to_queue(ticket):
    conn = get_db()
    try:
        with conn.cursor() as cur:

            # Check if service belongs to EIMD division
            cur.execute("""
                SELECT pf.division
                FROM srf_servicerequest sr
                JOIN process_flow_service pf ON pf.id = sr.service_availed_id
                WHERE sr.id = %s
            """, (ticket,))
            service_row = cur.fetchone()
            is_eimd = service_row is not None and service_row['division'].lower() == 'eimd'

            auto_status   = 'waiting'
            next_staff    = None
            next_initials = None

            if not is_eimd:
                # Non-EIMD — remove from queue entirely
                cur.execute(
                    "UPDATE srf_servicerequest SET served_by_id=NULL, status='not_queued' WHERE id=%s",
                    (ticket,)
                )
            else:
                # EIMD — run round-robin
                cur.execute("""
                    SELECT au.id, au.username AS initials
                    FROM auth_user au
                    JOIN accounts_userdata ud ON ud.user_id = au.id
                    WHERE ud.division = 'eimd' AND ud.is_absent = 0
                    ORDER BY au.id
                """)
                available = cur.fetchall()

                if available:
                    cur.execute(
                        "SELECT served_by_id FROM srf_servicerequest "
                        "WHERE status = 'serving' "
                        "AND served_by_id IS NOT NULL"
                    )
                    busy_ids = [r['served_by_id'] for r in cur.fetchall()]

                    cur.execute("""
                        SELECT served_by_id
                        FROM srf_servicerequest
                        WHERE served_by_id IS NOT NULL
                        ORDER BY id DESC
                        LIMIT 1
                    """)
                    last_row   = cur.fetchone()
                    last_id    = last_row['served_by_id'] if last_row else None
                    last_index = next((i for i, s in enumerate(available) if s['id'] == last_id), None)
                    next_index = (last_index + 1) % len(available) if last_index is not None else 0

                    next_staff    = available[next_index]['id']
                    next_initials = available[next_index]['initials']
                    auto_status   = 'waiting' if len(busy_ids) >= 4 else 'serving'

                cur.execute(
                    """UPDATE srf_servicerequest 
                        SET served_by_id=%s, 
                        status=%s,  
                        date_served=NOW()
                    WHERE id=%s""",
                    (next_staff, auto_status, ticket)
                )

        conn.commit()
        return jsonify({
            'auto_status':    auto_status,
            'next_staff':     next_staff,
            'staff_initials': next_initials,
            'is_eimd':        is_eimd,
        })
    except Exception as e:
        conn.rollback()
        tb = traceback.format_exc()
        print("=== ADD TO QUEUE ERROR ===")
        print(tb)
        return jsonify({'error': str(e), 'traceback': tb}), 500
    finally:
        conn.close()

@app.route('/api/queue/<int:id>/assign', methods=['PUT'])
def assign_processor(id):
    data     = request.get_json() or {}
    initials = data.get('initials', '')
    conn     = get_db()
    try:
        with conn.cursor() as cur:
            if initials:
                cur.execute("SELECT id FROM auth_user WHERE username = %s", (initials,))
                row      = cur.fetchone()
                staff_id = row['id'] if row else None
            else:
                staff_id = None
            cur.execute(
                "UPDATE srf_servicerequest SET served_by_id=%s WHERE id=%s",
                (staff_id, id)
            )
        conn.commit()
        return jsonify({'ok': True})
    finally:
        conn.close()

@app.route('/api/queue/<int:ticket>/serve', methods=['PUT'])
def serve_ticket(ticket):
    conn = get_db()
    try:
        with conn.cursor() as cur:
            # Check global serving cap
            cur.execute(
                "SELECT COUNT(*) AS cnt FROM srf_servicerequest "
                "WHERE status = 'serving'"
            )
            serving_count = cur.fetchone()['cnt']

            if serving_count >= 100:
                return jsonify({'error': 'Maximum of 100 clients being served at a time.'}), 400

            # Get the assigned processor for this ticket
            cur.execute(
                "SELECT served_by_id FROM srf_servicerequest WHERE id=%s",
                (ticket,)
            )
            ticket_row = cur.fetchone()
            assigned_staff = ticket_row['served_by_id'] if ticket_row else None

            # Check if assigned processor is already serving someone else
            if assigned_staff:
                cur.execute(
                    "SELECT COUNT(*) AS cnt FROM srf_servicerequest "
                    "WHERE status = 'serving' AND served_by_id = %s",
                    (assigned_staff,)
                )
                already_serving = cur.fetchone()['cnt']
                if already_serving > 0:
                    return jsonify({
                        'error': 'Assigned processor is currently serving another client.'
                    }), 400

            cur.execute(
                "UPDATE srf_servicerequest SET status='serving', date_served=NOW() WHERE id=%s",
                (ticket,)
            )
        conn.commit()
        return jsonify({'ok': True})
    finally:
        conn.close()
        

@app.route('/api/queue/<int:ticket>/done', methods=['PUT'])
def done_ticket(ticket):
    data     = request.get_json() or {}
    accepted = data.get('accepted', None)
    remarks  = data.get('remarks',  None)

    conn = get_db()
    try:
        with conn.cursor() as cur:

            # Get the current served_by_id to copy into entertained_by_id
            cur.execute(
                "SELECT served_by_id FROM srf_servicerequest WHERE id=%s",
                (ticket,)
            )
            row = cur.fetchone()
            served_by = row['served_by_id'] if row else None

            # Build dynamic SET clause
            fields = [
                "status='done'",
                "date_served=NOW()",
                "entertained_by_id=%s",
                "entertained_on=NOW()",
            ]
            values = [served_by]

            if accepted is not None:
                fields.append("accepted=%s")
                values.append(accepted)

            if remarks is not None:
                fields.append("remarks=%s")
                values.append(remarks)

            values.append(ticket)
            cur.execute(
                f"UPDATE srf_servicerequest SET {', '.join(fields)} WHERE id=%s",
                values
            )

            # Count remaining serving
            cur.execute(
                "SELECT COUNT(*) AS cnt FROM srf_servicerequest "
                "WHERE status='serving'"
            )
            serving_count = cur.fetchone()['cnt']

            next_pending = None
            if serving_count < 4:
                cur.execute(
                    "SELECT served_by_id FROM srf_servicerequest "
                    "WHERE status = 'serving' "
                    "AND served_by_id IS NOT NULL "
                    "ORDER BY id"
                )
                busy_ids = [r['served_by_id'] for r in cur.fetchall()]

                cur.execute(
                    "SELECT id, served_by_id FROM srf_servicerequest "
                    "WHERE status = 'waiting' "
                    "ORDER BY id ASC"
                )
                pending_list = cur.fetchall()

                for r in pending_list:
                    if r['served_by_id'] not in busy_ids:
                        next_pending = r['id']
                        break

                if next_pending:
                    cur.execute(
                        "UPDATE srf_servicerequest SET status='serving', date_served=NOW() WHERE id=%s",
                        (next_pending,)
                    )

        conn.commit()
        return jsonify({'ok': True, 'next_pending': next_pending})
    except Exception as e:
        conn.rollback()
        tb = traceback.format_exc()
        print("=== DONE TICKET ERROR ===")
        print(tb)
        return jsonify({'error': str(e), 'traceback': tb}), 500
    finally:
        conn.close()

@app.route('/api/queue/<ticket>/notes', methods=['PUT'])
def update_notes(ticket):
    data  = request.json or {}
    notes = data.get('notes', '')
    conn  = get_db()
    try:
        with conn.cursor() as cur:
            cur.execute("UPDATE srf_servicerequest SET remarks=%s WHERE id=%s", (notes, ticket))
        conn.commit()
        return jsonify({'ok': True})
    finally:
        conn.close()
'''
@app.route('/api/queue/reset', methods=['DELETE'])
def reset_queue():
    today = date.today().isoformat()
    conn  = get_db()
    try:
        with conn.cursor() as cur:
            cur.execute("DELETE FROM srf_servicerequest WHERE date_added=%s", (today,))
            # counter column is no longer used for ticket generation (tickets = srf_servicerequest id)
            cur.execute("UPDATE staff SET served=0")
        conn.commit()
        return jsonify({'ok': True})
    finally:
        conn.close()
'''

# ── TRACKER ────────────────────────────────────────────────────────────────────

@app.route('/api/tracker/establishments', methods=['GET'])
def tracker_establishments():
    """All transactions grouped by establishment, optionally filtered by date range."""
    date_from = request.args.get('from', date.today().isoformat())
    date_to   = request.args.get('to',   date.today().isoformat())
    conn = get_db()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT
                    e.id       AS estab_id,
                    q.bus_name AS estab_name,
                    CONCAT_WS(' ', NULLIF(TRIM(q.fname),''), NULLIF(TRIM(q.lname),'')) AS dealer,
                    q.id,
                    q.bus_name     AS client_name,
                    q.service_availed.description,
                    q.status,
                    q.remarks,
                    q.date_log,
                    q.date_log,
                    q.date_log,
                    q.bus_name_snapshot,
                    q.owner_snapshot,
                    s.initials AS processor
                FROM srf_servicerequest q

                WHERE q.date_log BETWEEN %s AND %s
                ORDER BY q.bus_name, q.date_log DESC, q.id DESC
            """, (date_from, date_to))
            rows = cur.fetchall()

        grouped = {}
        for r in rows:
            key = r['estab_id'] or 0
            if key not in grouped:
                grouped[key] = {
                    'estab_id':   r['estab_id'],
                    # Live name preferred; fall back to snapshot for historical records
                    'estab_name': r['estab_name'] or r['estab_name_snapshot'] or '(No Establishment)',
                    'dealer':     r['dealer'] or r['owner_snapshot'] or '',
                    'visits':     [],
                }
            grouped[key]['visits'].append({
                'ticket':      r['ticket'],
                'client_name': r['client_name'],
                'service':     r['service'],
                'status':      r['status'],
                'notes':       r['notes'],
                'time':        str(r['time_added']) if r['time_added'] else r['time_str'],
                'date':        str(r['date_added']),
                'processor':   r['processor'] or '—',
            })

        result = sorted(grouped.values(), key=lambda x: x['estab_name'])
        return jsonify(result)
    finally:
        conn.close()


@app.route('/api/tracker/services', methods=['GET'])
def tracker_services():
    """Count of each service availed, optionally filtered by date range."""
    date_from = request.args.get('from', date.today().isoformat())
    date_to   = request.args.get('to',   date.today().isoformat())
    conn = get_db()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT
                    q.service_availed.description,
                    COUNT(*)                                                              AS total,
                    SUM(q.status = 'done')                                               AS done,
                    SUM(q.status = 'serving')                                            AS serving,
                    SUM(q.status = 'waiting')                                            AS waiting,
                    GROUP_CONCAT(DISTINCT q.bus_name ORDER BY q.bus_name SEPARATOR ', ') AS establishments
                FROM srf_servicerequest q
                LEFT JOIN srf_servicerequest e ON q.estab_id = e.id
                WHERE q.date_log BETWEEN %s AND %s
                  AND q.service_availed.description IS NOT NULL
                GROUP BY q.service_availed.description
                ORDER BY total DESC
            """, (date_from, date_to))
            return jsonify(cur.fetchall())
    finally:
        conn.close()


@app.route('/api/tracker/summary', methods=['GET'])
def tracker_summary():
    """Quick stats for the tracker dashboard."""
    date_from = request.args.get('from', date.today().isoformat())
    date_to   = request.args.get('to',   date.today().isoformat())
    conn = get_db()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT
                    COUNT(*)                   AS total_transactions,
                    COUNT(DISTINCT q.estab_id) AS unique_establishments,
                    SUM(q.status = 'done')     AS completed,
                    SUM(q.status = 'waiting')  AS waiting,
                    SUM(q.status = 'serving')  AS serving,
                    COUNT(DISTINCT q.entertained_by_id) AS processors_active
                FROM srf_servicerequest q
                WHERE q.date_log BETWEEN %s AND %s
            """, (date_from, date_to))
            return jsonify(cur.fetchone())
    finally:
        conn.close()

# ── RUN ────────────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)