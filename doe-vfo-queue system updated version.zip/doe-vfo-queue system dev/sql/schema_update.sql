-- ============================================================
--  schema_update.sql
--  Run this ONCE to upgrade your existing doe_queuing database
-- ============================================================

USE doe_queuing;

-- ── Establishments table (replaces data.js ESTABLISHMENTS) ──
CREATE TABLE IF NOT EXISTS establishments (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    business   VARCHAR(500) NOT NULL,
    dealer     VARCHAR(500) DEFAULT '',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ── Add estab_id + notes to queue_entries ───────────────────
ALTER TABLE queue_entries
    ADD COLUMN IF NOT EXISTS estab_id INT DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS notes    TEXT DEFAULT NULL,
    ADD FOREIGN KEY (estab_id) REFERENCES establishments(id);
