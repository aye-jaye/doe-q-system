-- ============================================================
--  DOE Visayas Field Office – Queuing System
--  schema.sql  |  Run this ONCE to set up your database
-- ============================================================

CREATE DATABASE IF NOT EXISTS doe_queuing;
USE doe_queuing;

-- ── Staff ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS staff (
    id         INT PRIMARY KEY,
    initials   VARCHAR(20)  NOT NULL,
    absent     TINYINT(1)   DEFAULT 0,
    served     INT          DEFAULT 0
);

-- Seed staff list (mirrors data.js STAFF array)
INSERT IGNORE INTO staff (id, initials) VALUES
  (1,  'RCE'),  (2,  'HML'),  (3,  'JPC'),
  (4,  'EBTD'), (5,  'SCJ'),  (6,  'CKIP'),
  (7,  'CMMU'), (8,  'JFMG'), (9,  'RLBM'),
  (10, 'JZB'),  (11, 'CMJL'), (12, 'ABB'),
  (13, 'JFGA'), (14, 'MCEP'), (15, 'KVPT'),
  (16, 'MCGD');

-- ── Queue entries ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS queue_entries (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    ticket     VARCHAR(20)  UNIQUE NOT NULL,
    name       VARCHAR(200),
    service    VARCHAR(500),
    estab      VARCHAR(500),
    email      VARCHAR(200),
    mobile     VARCHAR(50),
    address    TEXT,
    staff_id   INT,
    status     VARCHAR(20)  DEFAULT 'waiting',   -- waiting | serving | done
    time_str   VARCHAR(20),
    created_at TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    date_added DATE         DEFAULT (CURDATE()),
    FOREIGN KEY (staff_id) REFERENCES staff(id)
);

-- ── Ticket counter (single row) ───────────────────────────────
CREATE TABLE IF NOT EXISTS ticket_counter (
    id           INT PRIMARY KEY DEFAULT 1,
    counter      INT DEFAULT 7001,   -- matches TICKET_START in data.js
    assign_index INT DEFAULT 0
);

INSERT IGNORE INTO ticket_counter (id, counter, assign_index)
VALUES (1, 7001, 0);
