-- ============================================================
--  migrate_fixes.sql
--  Run this ONCE on an existing doe_queuing database to apply
--  the fixes from the code review.
--  Safe to run repeatedly (uses IF EXISTS / IF NOT EXISTS).
-- ============================================================

USE doe_queuing;

-- ── 1. Drop window_num from staff ────────────────────────────
-- window_num is no longer used anywhere in the application.
SET @col_exists = (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = 'doe_queuing'
      AND TABLE_NAME   = 'staff'
      AND COLUMN_NAME  = 'window_num'
);
SET @sql = IF(@col_exists > 0,
    'ALTER TABLE staff DROP COLUMN window_num',
    'SELECT "window_num already removed"'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ── 2. Ensure ticket_counter row exists ───────────────────────
INSERT IGNORE INTO ticket_counter (id, counter, assign_index)
VALUES (1, 7001, 0);
