-- ============================================================
--  fix_estab_source.sql
--  Run this ONCE in HeidiSQL to switch establishments source
--  to srf_servicerequest
-- ============================================================

USE doe_queuing;

-- Drop the old foreign key on estab_id (if it exists)
-- Find the FK name first and drop it
SET @fk = (
    SELECT CONSTRAINT_NAME
    FROM information_schema.KEY_COLUMN_USAGE
    WHERE TABLE_SCHEMA = 'doe_queuing'
      AND TABLE_NAME   = 'queue_entries'
      AND COLUMN_NAME  = 'estab_id'
      AND REFERENCED_TABLE_NAME IS NOT NULL
    LIMIT 1
);

SET @sql = IF(@fk IS NOT NULL,
    CONCAT('ALTER TABLE queue_entries DROP FOREIGN KEY ', @fk),
    'SELECT "No FK to drop"'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ── Recreate views using srf_servicerequest ───────────────────

CREATE OR REPLACE VIEW view_tracker AS
SELECT
    q.date_added        AS date,
    q.time_str          AS time,
    q.ticket,
    e.id                AS estab_id,
    e.bus_name          AS establishment,
    q.name              AS client_name,
    q.service           AS service_availed,
    s.initials          AS processor,
    q.status,
    q.notes             AS remarks,
    q.mobile,
    q.email,
    q.address
FROM queue_entries q
LEFT JOIN srf_servicerequest e ON q.estab_id = e.id
LEFT JOIN staff              s ON q.staff_id = s.id
ORDER BY q.date_added DESC, q.id DESC;


CREATE OR REPLACE VIEW view_estab_summary AS
SELECT
    e.id                        AS estab_id,
    e.bus_name                  AS establishment,
    COUNT(*)                    AS total_visits,
    SUM(q.status = 'done')      AS completed,
    SUM(q.status = 'waiting')   AS waiting,
    SUM(q.status = 'serving')   AS serving,
    MIN(q.date_added)           AS first_visit,
    MAX(q.date_added)           AS last_visit
FROM queue_entries q
LEFT JOIN srf_servicerequest e ON q.estab_id = e.id
GROUP BY e.id, e.bus_name
ORDER BY total_visits DESC;


CREATE OR REPLACE VIEW view_service_summary AS
SELECT
    q.service                   AS service_availed,
    COUNT(*)                    AS total,
    SUM(q.status = 'done')      AS completed,
    SUM(q.status = 'waiting')   AS waiting,
    SUM(q.status = 'serving')   AS still_serving,
    MIN(q.date_added)           AS first_availed,
    MAX(q.date_added)           AS last_availed
FROM queue_entries q
WHERE q.service IS NOT NULL
GROUP BY q.service
ORDER BY total DESC;
