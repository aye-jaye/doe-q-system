/**
 * queue.js  (Flask + MySQL version)
 * ----------------------------------
 * Same interface as before, but all state is now stored in MySQL via the
 * Flask API.  In-memory copies are kept for fast reads; writes go to the server.
 *
 * Depends on: data.js (STAFF, TICKET_PREFIX, TICKET_START)
 */

// ─── CONFIG ──────────────────────────────────────────────────────────────────

// Where your Flask server is running.
// When Flask serves your HTML too (using send_from_directory), just use ''.
const API_BASE = '';   // e.g. 'http://localhost:5000' if running separately

// ─── STATE ───────────────────────────────────────────────────────────────────

// Working copy of staff – mutated as absent/served change
let staff = [];

// Queue entries – synced from server on load, updated locally on each action
let queue = [];

let ticketCounter   = 0;   // actual value synced from server
let nextAssignIndex = 0;

// ─── LOAD / SYNC FROM SERVER ─────────────────────────────────────────────────

/**
 * On load: wipe any stale localStorage, then fetch fresh state from server.
 */
async function loadState() {
  try { localStorage.removeItem('doe-queue-state'); } catch(_) {}
  await syncFromServer();
}

/**
 * Fetch the latest queue + staff from the server and update in-memory state.
 * Called once on boot, then every 5 s by startPolling() so all devices stay
 * in sync without anyone needing to refresh.
 */
async function syncFromServer() {
  try {
    const [qRes, sRes] = await Promise.all([
      fetch(`${API_BASE}/api/queue`),
      fetch(`${API_BASE}/api/staff`),
    ]);
    const qData = await qRes.json();
    const sData = await sRes.json();

    // populate staff from auth_user
    staff.length = 0;
    sData.forEach(s => {
      staff.push({
        id:       s.id,
        initials: s.username,
        absent:   s.is_absent,
        served:   s.served || 0,
      });
    });

    ticketCounter   = qData.ticketCounter;
    nextAssignIndex = qData.nextAssignIndex;

    queue = qData.queue.map(e => ({
      ...e,
      staff: e.staff_initials
        ? (staff.find(s => s.initials === e.staff_initials) || { initials: e.staff_initials })
        : null,
    }));

    if (typeof onServerSync === 'function') onServerSync();

  } catch (err) {
    console.warn('Could not reach Flask server.', err);
  }
}

/** Start polling the server every N ms. Call once after initial load. */
function startPolling(intervalMs = 5000) {
  setInterval(syncFromServer, intervalMs);
}

/** No-op — localStorage is no longer used. */
function saveState() {}

// ─── HELPERS ─────────────────────────────────────────────────────────────────

function getAvailableStaff() {
  return staff.filter(s => !s.absent);
}

function assignNextStaff() {
  const avail = getAvailableStaff();
  if (!avail.length) return null;
  const s = avail[nextAssignIndex % avail.length];
  nextAssignIndex++;
  return s;
}

// ─── QUEUE ACTIONS (now async) ───────────────────────────────────────────────

/**
 * Add a new client to the queue.
 * Returns the created entry so the caller can show the ticket modal.
 */
async function addToQueue({ name, service, estab, estab_id, email, mobile, address, classification }) {
  const res = await fetch(`${API_BASE}/api/add_to_queue`, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ name, service, estab, estab_id, email, mobile, address, classification }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    console.error('addToQueue error:', err);
    alert('Error creating service request: ' + (err.error || res.statusText));
    return null;
  }

  const entry = await res.json();

  // Re-link staff reference to the live in-memory object
  if (entry.staff) {
    entry.staff = staff.find(s => s.id === entry.staff.id) || entry.staff;
  }

  queue.push(entry);
  saveState();
  return entry;
}

/**
 * Pull the next waiting client into "serving" status.
 * Returns the entry, or null if queue is empty / all windows busy.
 */
async function callNextClient() {
  const next = queue.find(q => q.status === 'waiting');
  if (!next) return null;

  const busyIds = new Set(
    queue
      .filter(q => q.status === 'serving' && q.staff)
      .map(q => q.staff.id)
  );

  // Re-assign if the current staff is absent or already serving someone
  if (!next.staff || next.staff.absent || busyIds.has(next.staff.id)) {
    const free = getAvailableStaff().find(s => !busyIds.has(s.id));
    if (!free) return null;   // all windows busy
    next.staff = free;
  }

  await fetch(`${API_BASE}/api/queue/${next.ticket}/serve`, { method: 'PUT' });
  next.status = 'serving';
  return next;
}

/** Manually start serving a specific queue entry (by index). */
async function serveByIndex(index) {
  const entry = queue[index];
  if (!entry) return;
  if (!entry.staff || entry.staff.absent) {
    entry.staff = assignNextStaff();
  }
  await fetch(`${API_BASE}/api/queue/${entry.id}/serve`, { method: 'PUT' });
  entry.status = 'serving';
  saveState();
}

/** Mark a queue entry as done and increment the staff's served count. */
// queue.js — update method to match
async function markDoneByIndex(index) {
  const entry = queue[index];
  if (!entry) return;
  const res = await fetch(`${API_BASE}/api/queue/${entry.id}/done`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ accepted: null, remarks: '' }),
  });
  if (res.ok) entry.status = 'done';
  await syncFromServer();
  saveState();
}

/**
 * Toggle a staff member's absent flag.
 * When marked absent, any WAITING tickets assigned to them are reassigned.
 */
async function toggleStaffAbsent(staffId) {
  const member = staff.find(s => s.id === staffId);
  if (!member) return;

  await fetch(`${API_BASE}/api/staff/${staffId}/toggle`, { method: 'PUT' });
  member.absent = !member.absent;

  if (member.absent) {
    queue
      .filter(q => q.status === 'waiting' && q.staff && q.staff.id === staffId)
      .forEach(q => {
        const avail = getAvailableStaff();
        if (avail.length) q.staff = avail[0];
      });
  }
  saveState();
}

/** Reset the entire day (deletes today's queue and resets counters). */
/**async function clearState() {
  await fetch(`${API_BASE}/api/queue/reset`, { method: 'DELETE' });
  localStorage.removeItem(STORAGE_KEY);
  queue = [];
  ticketCounter = TICKET_START;
  nextAssignIndex = 0;
  staff.forEach(member => {
    member.absent = false;
    member.served = 0;
  });
} */

// ─── STATS ───────────────────────────────────────────────────────────────────

function getStats() {
  return {
    waiting: queue.filter(q => q.status === 'waiting').length,
    serving: queue.filter(q => q.status === 'serving').length,
    done:    queue.filter(q => q.status === 'done').length,
  };
}